@echo off
rem Wind Waker HD Online - launcher (serveur, mutateurs, boutique, skins, convertisseur GameCube)
rem Java 21 est fourni dans le dossier runtime : rien a installer.
cd /d "%~dp0"
if exist "runtime\bin\javaw.exe" (
    start "" "runtime\bin\javaw.exe" -jar "WWHD-Online-Launcher.jar"
    exit /b 0
)
where javaw >nul 2>nul || (echo Le dossier runtime manque et Java 17 ou plus n'est pas installe : https://adoptium.net & pause & exit /b 1)
start "" javaw -jar "WWHD-Online-Launcher.jar"
