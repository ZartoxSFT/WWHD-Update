Third-party software in this package and its license files:
  Cemu (MPL-2.0)               Cemu.txt
  Dear ImGui (MIT)             Dear-ImGui.txt
  ImGuizmo (MIT)               ImGuizmo.txt
  LLVM libc++ (Apache-2.0 WITH LLVM-exception) LLVM-libc.txt
  LZ4 (BSD-2-Clause)           LZ4.txt
  Python (PSF-2.0)             Python.txt
  SDL3 (zlib)                  SDL3.txt
  Vulkan-Headers (Apache-2.0)  Vulkan-Headers.txt
  Zstandard (BSD-3-Clause)     Zstandard.txt
  fmt (MIT)                    fmt.txt
  glslang (BSD-3-Clause and others) glslang.txt
  metal-cpp (Apache-2.0)       metal-cpp.txt
  xxHash (BSD-2-Clause)        xxHash.txt
  zlib (zlib)                  zlib.txt
